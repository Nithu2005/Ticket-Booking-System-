# movie_ticket
Online Movie ticket booking system php project
